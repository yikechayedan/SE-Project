# 复杂图像数据集样例

这是一个包含子目录的复杂图像数据集样例，用于测试图像上传功能。

## 文件结构
- data.json: 数据集的JSON文件，包含元数据和样本数据
- images/: 图片目录
  - cat1.jpg: 猫的图片
- images/landscape/: 风景图片目录
  - nature1.jpg: 自然风景图片
- images/portrait/: 人物图片目录
  - person1.jpg: 人物肖像图片
- documents/: 文档目录
  - sign1.png: 标志图片

## 数据格式
JSON文件包含：
- metadata: 数据集元信息
- data: 实际数据数组

每个数据项包含：
- id: 唯一标识符
- input: 问题或指令
- image: 引用的图片文件名（使用相对路径）
- reference: 期望的答案或描述

## 特点
- 支持子目录结构
- JSON包含metadata和data字段
- 图片路径使用相对路径
- 适用于复杂的数据集组织

## 使用方法
1. 将此ZIP文件上传到PolyMetric平台
2. 选择"图像"类别
3. 选择适当的测评类型（主观/客观/对抗）
4. 系统会自动识别图片数量和样本数量
5. 支持复杂的目录结构
